package demo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.io.File;
import java.io.IOException;
import java.util.UUID;


import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import demo.utils.Response;

import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.util.StringUtils;
//import com.iot.common.annotation.Log;
//import com.iot.common.enums.BusinessType;
import demo.entity.AnswerLog;
import demo.entity.User;

import demo.service.AnswerLogService;
import demo.mapper.AnswerLogMapper;

//import com.iot.common.core.page.TableDataInfo;

/**
 * 【请填写功能名称】Controller
 * 
 * @author admin
 *  
 */
@Controller
@RequestMapping("/answerLog")
public class AnswerLogController // extends BaseController
{
    private String prefix = "demo/answerLog";

    @Autowired
    private AnswerLogService answerLogService;

    @Autowired
    private AnswerLogMapper answerLogMapper;

    @Value("${uploadFile.location}")
    private String uploadFileLocation;
    
    @Value("${uploadFile.resourceHandler}")
    private String resourceHandler;
    
    
    /*
      分页查询   使用方法： 得到对象是map   也就是多个map的list
   controller这里的page里面可以直接放实体  不影响最终的结果  或者自定义vo作为
   返回集合中的对象
    */
    @ResponseBody
    @RequestMapping({ "/test"})
    //@PostConstruct
    Object test(){
    	IPage<AnswerLog> page=new  Page<AnswerLog>(1, 10);
    	//page=answerLogMapper.getMysqlByPage(page, "22");
    	
    	Map<String, Object> map=new HashMap<>();
    	map.put("content", "1111");
    	IPage<Map<String,Object>>  pages=answerLogMapper.getMysqlByPageMap(page, map);
    	
    	
    	System.out.println();
    	return page;
    }



    //参数以 form表单提交    链接后面的参数提交均可以
    @RequestMapping({"", "/index"})
    public String toIndex(@RequestParam(value = "page", defaultValue = "1") Integer current,
    		@RequestParam(value = "name", defaultValue = "") String name,
    		@RequestParam(value = "keyword", defaultValue = "") String keyword,
    		Model model, HttpSession session) {
    	//	User	loginUser=(User)  session.getAttribute("user")  ;
		Map<String,Object> searchMap=new HashMap<String, Object>();
		
		QueryWrapper<AnswerLog>  queryWrap=new QueryWrapper<AnswerLog>();
		if(!"**null**".equals(name) && !"".equals(name) ){
			searchMap.put("name",name);
    		queryWrap.like("name", name);
    	}
		searchMap.put("name",name);
		if(!"**null**".equals(keyword) && !"".equals(keyword) ){
			
    	//	queryWrap.like("keyword", keyword);
    	}
		searchMap.put("keyword",keyword);
		
		//queryWrap.orderByDesc("create_time");
		
    	Map<String,Object> map=new HashMap<>();
    	
    	//List<AnswerLog> list=answerLogService.list(queryWrap);
    	//page.setRecords(list);
    	
    	Page<AnswerLog> page = new Page<AnswerLog>(current, 10);
    	page=answerLogService.page(page,queryWrap);
    	 
    	
    	
    	
    	model.addAttribute("searchMap", searchMap);
    	
        model.addAttribute("answerLogs", page.getRecords());
        model.addAttribute("pre", page.getCurrent() - 1);
        model.addAttribute("next", page.getCurrent() + 1);
        model.addAttribute("total", page.getPages());
        model.addAttribute("current", current);
        return "answerLog/answerLoglist";
    }
	
	
	
	

	
	@PostMapping("/delete")
    @ResponseBody
    public Response deleteAnswerLog(@RequestParam("id") Integer id, HttpSession session) {
    //	User	loginUser=(User)  session.getAttribute("user")  ;
        boolean i = answerLogService.removeById(id);
        if (i ) {
            return Response.SUCCESS();
        }
        return Response.DEFEAT();
    }

    @GetMapping("/add")
    public String toInsertPerson() {
        return "answerLog/answerLog_add";
    }

    @PostMapping("/post")
    public String insert(AnswerLog item, HttpSession session
    /* ,@RequestParam("file") MultipartFile uploadFile */
       ) {  
    	 if(session.getAttribute("user")!=null){
    		    User	user=(User)  session.getAttribute("user")  ;
	        }
	         String dir=uploadFileLocation;
    	/* try {
		 if (StringUtils.hasLength(uploadFile.getOriginalFilename())) {
				 String uuid = UUID.randomUUID().toString();
			     String suffix = uploadFile.getOriginalFilename().substring(uploadFile.getOriginalFilename().lastIndexOf("."));
			     File file = new File(dir);
			     if (!file.exists()) {
			         file.mkdir();
			     }
//			     String saveFileName=uploadFile.getOriginalFilename();
			     String saveFileName=uuid + suffix;
				 String savePath = dir+ "/" + saveFileName;
				 uploadFile.transferTo(new File(savePath));
				//  item.setPhoto("/uploadFiles/"+saveFileName);
				 resourceHandler=resourceHandler.replace("/**", "");
	             item.setPhoto(resourceHandler+"/"+saveFileName);
	         
				
			  }
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}*/
    //	 item.setCreateTime(new Date());
        boolean b = answerLogService.save(item);
        return "redirect:/answerLog";
    }

    
    @GetMapping("/update")
    public String toUpdate(@RequestParam("id") Integer id, Model model) {
        AnswerLog item = answerLogService.getById(id);
        model.addAttribute("answerLog", item);
        return "answerLog/answerLog_edit";
    }

    @PostMapping("/put")
    public String updatePerson(AnswerLog item,HttpSession session) {
        //	User	loginUser=(User)  session.getAttribute("user")  ;
        
    	answerLogService.updateById(item);
        return "redirect:/answerLog";
    }
   
   
    @GetMapping("/detail")
    public String toDetail(@RequestParam("id") Integer id, Model model) {
        AnswerLog item = answerLogService.getById(id);
        model.addAttribute("item", item);
        return "answerLog/answerLog_detail";
    }
   
    /**
	 * json格式返回
	 * @param id
	 * @return
	 */
	@PostMapping("/ajaxUpdate")
    @ResponseBody
    public Response ajaxUpdate( AnswerLog item  ) {
        boolean i = answerLogService.updateById(item);
        if (i ) {
            return Response.SUCCESS();
        }
        return Response.DEFEAT();
    }
	
	
	
	@PostMapping("/ajaxSave")
    @ResponseBody
    public Response ajaxSave( AnswerLog item  ) {
        boolean i = answerLogService.save(item);
        if (i ) {
            return Response.SUCCESS();
        }
        return Response.DEFEAT();
    }
	
	 //表单形式提交   链接参数形式提交
	 @RequestMapping({"/ajaxSelect"})
	    public Response ajaxSelect(@RequestParam(value = "page", defaultValue = "1") Integer current,
	    		@RequestParam(value = "name", defaultValue = "") String name,
	    		@RequestParam(value = "keyword", defaultValue = "") String keyword,
	    		Model model) {
			Map<String,Object> searchMap=new HashMap<String, Object>();
			
			QueryWrapper<AnswerLog>  queryWrap=new QueryWrapper<AnswerLog>();
			if(!"**null**".equals(name) && !"".equals(name) ){
				searchMap.put("name",name);
	    		queryWrap.like("name", name);
	    	}
			searchMap.put("name",name);
			if(!"**null**".equals(keyword) && !"".equals(keyword) ){
				
	    	/*	queryWrap.and(wrapper -> wrapper.like("name", keyword)
				.or().like("name", keyword)
				);    */
	    	}
			searchMap.put("keyword",keyword);
			
			//queryWrap.orderByDesc("create_time");
			
	    	Map<String,Object> map=new HashMap<>();
	    	
	    	Page<AnswerLog> page = new Page<AnswerLog>(current, 10);
	    	page=answerLogService.page(page,queryWrap);
	    	
	    	map.put("searchMap", searchMap);
	    	
	    	map.put("list", page.getRecords());
	    	map.put("pre", page.getCurrent() - 1);
	    	map.put("next", page.getCurrent() + 1);
	    	map.put("total", page.getPages());
	    	map.put("current", current);
	    	
	    	return Response.SUCCESS(map);
	    	
	    }
	    
	 //以post JSON 格式请求数据
	 @PostMapping({"/ajaxJsonSelect"})
	 @ResponseBody
	    public Response ajaxPostBodySelect(@RequestBody  AnswerLog answerLog) {
			
			QueryWrapper<AnswerLog>  queryWrap=new QueryWrapper<AnswerLog>();
			
			if(answerLog.getKeyword()!=null ){
	    		queryWrap.and(wrapper -> wrapper.like("content", answerLog.getKeyword())
				.or().like("content", answerLog.getKeyword())
				);    
	    	}
			
			//queryWrap.orderByDesc("create_time");
			
	    	Map<String,Object> map=new HashMap<>();
	    	
	    	Page<AnswerLog> page = new Page<AnswerLog>(answerLog.getCurrentPage(), 10);
	    	page=answerLogService.page(page,queryWrap);
	    	
	    	
	    	map.put("list", page.getRecords());
	    	map.put("pre", page.getCurrent() - 1);
	    	map.put("next", page.getCurrent() + 1);
	    	map.put("total", page.getPages());
	    	map.put("current", answerLog.getCurrentPage());
	    	
	    	return Response.SUCCESS(map);
	    	
	    }    
   
}
