package demo.controller;

import net.minidev.json.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import demo.entity.User;
import demo.mapper.UserMapper;
import demo.service.UserService;
import demo.utils.Response;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;


/**
 * 
*    单例模式   多次用户接口前端请求只会生成一次实例
* @version
*/


@Controller
public class UserController {
    @Autowired
    private UserService userService;
    
    @Autowired
    private UserMapper userMapper;
    
  
    
    
    
//    @SystemControllerLog(description = "登陆", operModul = "login")
    @GetMapping("/login")
    public String toLogin(HttpServletRequest request, Map map) {
        String referer = request.getHeader("Referer");
        String url = request.getParameter("url");
        if (url != null && !url.equals("")) {
            map.put("url", url);
            // 如果请求头本身包含登录，将重定向url设为空，让后台通过用户角色进行选择跳转
        } else if (referer != null && referer.contains("/login")) {
            map.put("url", "");
        } else {
            // 否则的话，就记住请求头中的原始访问路径
            map.put("url", referer);
        }
        return "user/login";
    }
   
//    @SystemControllerLog(description = "登陆验证", operModul = "login")
    @PostMapping("/user/login")
    public String login(User user, HttpSession session,Model model) {
        System.out.println("登陆");
        User login = userService.login(user);
        if (login != null) {
            session.setAttribute("user", login);
            return "redirect:/";
        }else{
        	model.addAttribute("msg", "用户名或密码错误");
        }
        return "user/login";
//        return "redirect:/login";
    }

    
    
    
//    @SystemControllerLog(description = "注册跳转", operModul = "login")
    @GetMapping("/register")
    public String toRegister() {
        return "user/register";
    }
    
    @PostMapping("/user/registerVer")
    @ResponseBody
    public Response registerVer(@RequestBody User user) {
    	QueryWrapper<User> queryWrapper=new QueryWrapper<User>();
    	queryWrapper.eq("username", user.getUsername());
		User user2=userMapper.selectOne(queryWrapper);
        if(user2!=null){
        	return Response.Fail();
        	
        }
        return Response.SUCCESS();
	
    }
    
    

//    @SystemControllerLog(description = "注册", operModul = "login")
    @PostMapping("/user/register")
    public String register(User user) {
    	if(user.getType()==null){
    		user.setType(2);
    	}
    	
//    	user.setEmail("");
        System.out.println("======="+user.toString());
        int register = userService.register(user);
        if (register > 0) {
            return "redirect:/login";
        }
        return "redirect:/register";
    }

//    @SystemControllerLog(description = "退出", operModul = "login")
    @GetMapping("/user/logout")
    public String logout(HttpSession session) {
        session.removeAttribute("user");
        return "redirect:/index";
    }
    
    
    /*public String toProductList(Model model) {
        List<User> users = userService.listAll();
        model.addAttribute("users", users);
        return "admin/userlist";
    }*/
    
    @GetMapping("/user/userlist")
    public String toUserIndex(@RequestParam(value = "page", defaultValue = "1") Integer current,
    		@RequestParam(value = "username", defaultValue = "**null**") String username,
    		Model model) {
    	Map<String,Object> map=new HashMap<>();
    	if(!"**null**".equals(username)){
    		map.put("username", username);
    	}
        Page<User> page = new Page<User>(current, 9);
        IPage<User> userPage = userService.getUserByPage(page,map);
        model.addAttribute("users", userPage.getRecords());
        model.addAttribute("pre", userPage.getCurrent() - 1);
        model.addAttribute("next", userPage.getCurrent() + 1);
        model.addAttribute("total", userPage.getPages());
        return "admin/userlist";
    }
    
    
    
    
    @PostMapping("/user/delete")
    @ResponseBody
    public Response deleteUser(@RequestParam("id") Integer id) {
        int i = userService.removeUserById(id);
        if (i > 0) {
            return Response.SUCCESS();
        }
        return Response.DEFEAT();
    }

    @GetMapping("/user/add")
    public String toInsertProduct() {
        return "admin/user_add";
    }

    @PostMapping("/user/post")
    public String insertProduct(User user) {
        int i = userService.addNewUser(user);
        return "redirect:/user/userlist";
    }

    
    @GetMapping("/user/update")
    public String toUpdateProduct(@RequestParam("id") Integer id, Model model) {
        User user = userService.getUserById(id);
        model.addAttribute("user", user);
        return "admin/user_update";
    }

    @PostMapping("/user/put")
    public String updateProduct(User user) {
        System.out.println(user.toString());
    	userService.updateUser(user);
        return "redirect:/user/userlist";
    }
    
    @PostMapping("/user/personinfoPut")
    public String personinfoPut(User user) {
    	userService.updateUser(user);
        return "redirect:/user/personinfo";
    }
    
    
    @GetMapping("/user/personinfo")
    public String personinfo(@RequestParam(value = "page", defaultValue = "1") Integer current,
    		@RequestParam(value = "username", defaultValue = "**null**") String username,
    		Model model,HttpServletRequest request) {
        System.out.println("=========personInfo");
    	Map<String,Object> map=new HashMap<>();
    	if(!"**null**".equals(username)){
    		map.put("username", username);
    	}
    	if(request.getSession().getAttribute("user")!=null){
    		 User	user=(User)request.getSession().getAttribute("user")  ;
    		 
    		 user= userService.getUserById(user.getId());
    		
    		 model.addAttribute("user", user);
    	     return "user/personinfo";
    		
        }
    	
        return "/login";
    }
    
    @GetMapping("/user/personinfoUpdate")
    public String personinfoUpdate(@RequestParam(value = "page", defaultValue = "1") Integer current,
    		@RequestParam(value = "username", defaultValue = "**null**") String username,
    		Model model,HttpServletRequest request) {
    	Map<String,Object> map=new HashMap<>();
    	if(!"**null**".equals(username)){
    		map.put("username", username);
    	}
    	if(request.getSession().getAttribute("user")!=null){
    		 User	user=(User)request.getSession().getAttribute("user")  ;
    		 
    		 user= userService.getUserById(user.getId());
    		
    		 model.addAttribute("user", user);
    	     return "user/personinfo_update";
    		
        }
    	
     /*   Page<User> page = new Page<User>(current, 9);
        IPage<User> userPage = userService.getUserByPage(page,map);
        model.addAttribute("users", userPage.getRecords());
        model.addAttribute("pre", userPage.getCurrent() - 1);
        model.addAttribute("next", userPage.getCurrent() + 1);
        model.addAttribute("total", userPage.getPages());*/
        return "/login";
    }
    
   
    
   
    
    
}
