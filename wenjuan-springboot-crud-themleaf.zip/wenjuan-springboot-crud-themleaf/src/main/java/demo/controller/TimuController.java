package demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import demo.utils.ImportExcelUtil;
import demo.utils.Response;

import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.util.StringUtils;

import demo.entity.Answer;
import demo.entity.AnswerLog;
//import com.iot.common.annotation.Log;
//import com.iot.common.enums.BusinessType;
import demo.entity.Timu;
import demo.entity.User;
import demo.entity.Wenjuan;
import demo.service.TimuService;
import demo.mapper.AnswerLogMapper;
import demo.mapper.AnswerMapper;
import demo.mapper.TimuMapper;
import demo.mapper.WenjuanMapper;

//import com.iot.common.core.page.TableDataInfo;

/**
 * 【请填写功能名称】Controller
 * 
 * @author admin
 * 
 */
@Controller
@RequestMapping("/timu")
public class TimuController // extends BaseController
{
	private String prefix = "demo/timu";

	@Autowired
	private TimuService timuService;

	@Autowired
	private TimuMapper timuMapper;

	@Value("${uploadFile.location}")
	private String uploadFileLocation;

	@Value("${uploadFile.resourceHandler}")
	private String resourceHandler;

	/*
	 * 分页查询 使用方法： 得到对象是map 也就是多个map的list controller这里的page里面可以直接放实体 不影响最终的结果
	 * 或者自定义vo作为 返回集合中的对象
	 */
	@ResponseBody
	@RequestMapping({ "/test" })
	// @PostConstruct
	Object test() {
		IPage<Timu> page = new Page<Timu>(1, 10);
		// page=timuMapper.getMysqlByPage(page, "22");

		Map<String, Object> map = new HashMap<>();
		map.put("content", "1111");
		IPage<Map<String, Object>> pages = timuMapper.getMysqlByPageMap(page,
				map);

		System.out.println();
		return page;
	}

	// 参数以 form表单提交 链接后面的参数提交均可以
	@RequestMapping({ "", "/index" })
	public String toIndex(
			@RequestParam(value = "page", defaultValue = "1") Integer current,
			@RequestParam(value = "name", defaultValue = "") String name,
			@RequestParam(value = "keyword", defaultValue = "") String keyword,
			Model model, HttpSession session) {
		// User loginUser=(User) session.getAttribute("user") ;
		Map<String, Object> searchMap = new HashMap<String, Object>();

		QueryWrapper<Timu> queryWrap = new QueryWrapper<Timu>();
		if (!"**null**".equals(name) && !"".equals(name)) {
			searchMap.put("name", name);
			queryWrap.like("name", name);
		}
		searchMap.put("name", name);
		if (!"**null**".equals(keyword) && !"".equals(keyword)) {

			// queryWrap.like("keyword", keyword);
		}
		searchMap.put("keyword", keyword);

		// queryWrap.orderByDesc("create_time");

		Map<String, Object> map = new HashMap<>();

		// List<Timu> list=timuService.list(queryWrap);
		// page.setRecords(list);

		Page<Timu> page = new Page<Timu>(current, 10);
		page = timuService.page(page, queryWrap);

		model.addAttribute("searchMap", searchMap);

		model.addAttribute("timus", page.getRecords());
		model.addAttribute("pre", page.getCurrent() - 1);
		model.addAttribute("next", page.getCurrent() + 1);
		model.addAttribute("total", page.getPages());
		model.addAttribute("current", current);
		return "timu/timulist";
	}

	@RequestMapping({ "/selTimu" })
	public String selTimu(
			@RequestParam(value = "page", defaultValue = "1") Integer current,
			@RequestParam(value = "name", defaultValue = "") String name,
			@RequestParam(value = "keyword", defaultValue = "") String keyword,
			@RequestParam(value = "wenjuanId") Integer wenjuanId, Model model,
			HttpSession session) {
		// User loginUser=(User) session.getAttribute("user") ;
		Map<String, Object> searchMap = new HashMap<String, Object>();

		QueryWrapper<Timu> queryWrap = new QueryWrapper<Timu>();
		if (!"**null**".equals(name) && !"".equals(name)) {
			searchMap.put("name", name);
			queryWrap.like("name", name);
		}
		searchMap.put("name", name);
		if (!"**null**".equals(keyword) && !"".equals(keyword)) {

			// queryWrap.like("keyword", keyword);
		}
		searchMap.put("keyword", keyword);

		// queryWrap.orderByDesc("create_time");

		Map<String, Object> map = new HashMap<>();

		// List<Timu> list=timuService.list(queryWrap);
		// page.setRecords(list);

		Page<Timu> page = new Page<Timu>(current, Integer.MAX_VALUE);
		// page=timuService.page(page,queryWrap);

		List<Timu> list = timuMapper.selectList(queryWrap);
		page.setRecords(list);

		Wenjuan wenjuan = wenjuanMapper.selectById(wenjuanId);
		List<Long> timuList = JSON.parseArray(wenjuan.getTimuIdlist(),
				Long.class);
		wenjuan.setTimuList(timuList);

		model.addAttribute("wenjuan", wenjuan);

		model.addAttribute("searchMap", searchMap);

		model.addAttribute("timus", page.getRecords());
		model.addAttribute("pre", page.getCurrent() - 1);
		model.addAttribute("next", page.getCurrent() + 1);
		model.addAttribute("total", page.getPages());
		model.addAttribute("current", current);
		return "timu/selTimu";
	}

	@Autowired
	private WenjuanMapper wenjuanMapper;

	@PostMapping("/selTimuSub")
	@ResponseBody
	public Response selTimuSub(@RequestParam Map<String, String> formMap,
			HttpSession session,
			@RequestParam(value = "wenjuanId") Integer wenjuanId
	/* ,@RequestParam("file") MultipartFile uploadFile */
	) {

		User user = (User) session.getAttribute("user");
		System.out.println(formMap);
		// double count=timuMapper.selectCount(null);
		double rightCount = 0;
		List<Integer> idList = new ArrayList<Integer>();
		for (String key : formMap.keySet()) {
			// Timu timu=timuMapper.selectById(key);
			if ("wenjuanId".equals(key)) {
				continue;
			}
			// System.out.println(key);
			String choice = formMap.get(key);

			System.out.println("key==" + key);

			idList.add(Integer.valueOf(key));
		}

		// QueryWrapper<Timu> queryWrapper=new QueryWrapper<Timu>();
		// timuMapper.selectList(queryWrapper);

		QueryWrapper<Wenjuan> queryWrapper = new QueryWrapper<Wenjuan>();
		Wenjuan wenjuan = wenjuanMapper.selectById(wenjuanId);

		Object jsonArray = JSON.toJSON(idList);

		wenjuan.setTimuIdlist(jsonArray.toString());

		wenjuanMapper.updateById(wenjuan);

		// double score=rightCount/count;
		//
		// user.setScore(score*100);
		// userMapper.updateById(user);

		return Response.SUCCESS();
	}

	@RequestMapping({ "/dajuan" })
	public String dajuan(
			@RequestParam(value = "page", defaultValue = "1") Integer current,
			@RequestParam(value = "name", defaultValue = "") String name,
			@RequestParam(value = "keyword", defaultValue = "") String keyword,
			@RequestParam(value = "wenjuanId") Integer wenjuanId,
			Model model, HttpSession session) {
		// User loginUser=(User) session.getAttribute("user") ;
		Map<String, Object> searchMap = new HashMap<String, Object>();

		QueryWrapper<Timu> queryWrap = new QueryWrapper<Timu>();
		if (!"**null**".equals(name) && !"".equals(name)) {
			searchMap.put("name", name);
			queryWrap.like("name", name);
		}
		searchMap.put("name", name);
		if (!"**null**".equals(keyword) && !"".equals(keyword)) {

			// queryWrap.like("keyword", keyword);
		}
		searchMap.put("keyword", keyword);

		// queryWrap.orderByDesc("create_time");

		Map<String, Object> map = new HashMap<>();

		// List<Timu> list=timuService.list(queryWrap);
		// page.setRecords(list);

		Page<Timu> page = new Page<Timu>(current, Integer.MAX_VALUE);
		// page=timuService.page(page,queryWrap);
		
		Wenjuan wenjuan = wenjuanMapper.selectById(wenjuanId);
		List<Long> timuList = JSON.parseArray(wenjuan.getTimuIdlist(),
				Long.class);
		
		if(timuList!=null && timuList.size()>0){
			queryWrap.in("id", timuList);
		}
		

		List<Timu> list = timuMapper.selectList(queryWrap);
		page.setRecords(list);

		model.addAttribute("searchMap", searchMap);

		model.addAttribute("timus", page.getRecords());
		model.addAttribute("pre", page.getCurrent() - 1);
		model.addAttribute("next", page.getCurrent() + 1);
		model.addAttribute("total", page.getPages());
		model.addAttribute("current", current);
		return "timu/dajuan";
	}

	@Autowired
	private AnswerMapper answerMapper;

	@Autowired
	private AnswerLogMapper answerLogMapper;

	@PostMapping("/jiaojuan")
	@ResponseBody
	public Response jiaojuan(@RequestParam Map<String, String> formMap,
			HttpSession session,
			@RequestParam(value = "wenjuanId") Integer wenjuanId
	/* ,@RequestParam("file") MultipartFile uploadFile */
	) {

		Map<String, Object> respMap=new HashMap<String, Object>();
		
		
		User user = (User) session.getAttribute("user");
		System.out.println(formMap);
		// double count=timuMapper.selectCount(null);
		
		Wenjuan wenjuan=wenjuanMapper.selectById(wenjuanId);
		
		if(wenjuan.getStarttime()!=null && wenjuan.getStarttime().before(new Date()) ){
			
			respMap.put("msg", "问卷未开始");
			
		}else if(wenjuan.getEndtime()!=null && wenjuan.getEndtime().before(new Date()) ){
			
			respMap.put("msg", "问卷已结束");
			
		}
		
		
		
		
		double rightCount = 0;
		for (String key : formMap.keySet()) {
			// Timu timu=timuMapper.selectById(key);
			if ("wenjuanId".equals(key)) {
				continue;
			}
			// System.out.println(key);
			String choice = formMap.get(key);

			QueryWrapper<Answer> queryWrapper = new QueryWrapper<Answer>();
			queryWrapper.eq("wenjuan_id", wenjuanId);
			queryWrapper.eq("answer_uid", user.getId());
			queryWrapper.orderByDesc("id");
			queryWrapper.last("limit 1");
			Answer answer = answerMapper.selectOne(queryWrapper);
			if (answer == null) {
				answer = new Answer();
				answer.setAnswerUid(user.getId().longValue());
				answer.setCreateTime(new Date());
				answer.setWenjuanId(wenjuanId.longValue());
				answer.setAnswerCount(1L);
				answerMapper.insert(answer);
				answer = answerMapper.selectOne(queryWrapper);

			} else {
				if(wenjuan.getCountLimit()!=null && wenjuan.getCountLimit()<= answer.getAnswerCount()){
				
					respMap.put("msg", "已超出次数，不能再参与调研，谢谢您的支持");
					return Response.Fail(respMap);
				}
				
				
				answer.setAnswerCount(answer.getAnswerCount() + 1);
				answerMapper.updateById(answer);
			}

			QueryWrapper<AnswerLog> queryWrapper1 = new QueryWrapper<AnswerLog>();
			queryWrapper1.eq("wenjuan_id", wenjuanId);
			queryWrapper1.eq("answer_id", answer.getId());
			queryWrapper1.eq("answer_uid", user.getId());
			queryWrapper1.eq("timu_id", key);

			AnswerLog answerLog = answerLogMapper.selectOne(queryWrapper1);
			if (answerLog == null) {
				answerLog = new AnswerLog();
				answerLog.setAnswerUid(user.getId().longValue());
				answerLog.setAnswerId(answer.getId());
				answerLog.setWenjuanId(wenjuanId.longValue());
				answerLog.setCreateTime(new Date());
				answerLog.setTimuId(Long.valueOf(key));
				answerLog.setTimuChoice(choice);
				answerLogMapper.insert(answerLog);
			} else {
				answerLog.setTimuChoice(choice);
				answerLogMapper.updateById(answerLog);
			}

		}
		// double score=rightCount/count;
		//
		// user.setScore(score*100);
		// userMapper.updateById(user);

		return Response.SUCCESS();
	}

	
	@RequestMapping({ "/tongji" })
	public String tongji(
			@RequestParam(value = "page", defaultValue = "1") Integer current,
			@RequestParam(value = "name", defaultValue = "") String name,
			@RequestParam(value = "keyword", defaultValue = "") String keyword,
			@RequestParam(value = "wenjuanId") Integer wenjuanId,
			Model model, HttpSession session) {
		 User loginUser=(User) session.getAttribute("user") ;
		Map<String, Object> searchMap = new HashMap<String, Object>();

		QueryWrapper<Timu> queryWrap = new QueryWrapper<Timu>();
		if (!"**null**".equals(name) && !"".equals(name)) {
			searchMap.put("name", name);
			queryWrap.like("name", name);
		}
		searchMap.put("name", name);
		if (!"**null**".equals(keyword) && !"".equals(keyword)) {

			// queryWrap.like("keyword", keyword);
		}
		searchMap.put("keyword", keyword);

		// queryWrap.orderByDesc("create_time");

		Map<String, Object> map = new HashMap<>();

		// List<Timu> list=timuService.list(queryWrap);
		// page.setRecords(list);

		Page<Timu> page = new Page<Timu>(current, Integer.MAX_VALUE);
		// page=timuService.page(page,queryWrap);

		List<Timu> list = timuMapper.selectList(queryWrap);
		
		
		for(Timu tmp:list){
			Map<String,Object> tongjiMap=new HashMap<String, Object>();
			tongjiMap.put("timuId", tmp.getId());
			tongjiMap.put("wenjuanId", wenjuanId);
			
			List<Map<String,Object>>  tongjiList=timuMapper.tongji1(tongjiMap);
			double allCount=timuMapper.tongji2(tongjiMap);
			
			DecimalFormat b=new DecimalFormat("0.00");
			
			for(Map<String,Object> tmpMap:tongjiList  ){
				if(tmpMap.get("timu_choice")!=null){
					String timu_choice=tmpMap.get("timu_choice").toString();
					
					if(timu_choice.equals("A")){
						tmp.setCh1Count(Integer.valueOf(tmpMap.get("count").toString()));
						if(allCount>0){
							double f=tmp.getCh1Count()/allCount;
							tmp.setCh1Percent(b.format(f*100)+"%");
						}
						
					}else if(timu_choice.equals("B")){
						tmp.setCh2Count(Integer.valueOf(tmpMap.get("count").toString()));
						if(allCount>0){
							double f=tmp.getCh2Count()/allCount;
							tmp.setCh1Percent(b.format(f*100)+"%");
						}
						
					}else if(timu_choice.equals("C")){
						tmp.setCh3Count(Integer.valueOf(tmpMap.get("count").toString()));
						if(allCount>0){
							double f=tmp.getCh3Count()/allCount;
							tmp.setCh3Percent(b.format(f*100)+"%");
						}
					}else if(timu_choice.equals("D")){
						tmp.setCh4Count(Integer.valueOf(tmpMap.get("count").toString()));
						if(allCount>0){
							double f=tmp.getCh4Count()/allCount;
							tmp.setCh4Percent(b.format(f*100)+"%");
						}
					}
					
					
				}
				
			}
			
			
			
		}
		
		
		
		
		page.setRecords(list);

		model.addAttribute("searchMap", searchMap);

		model.addAttribute("timus", page.getRecords());
		model.addAttribute("pre", page.getCurrent() - 1);
		model.addAttribute("next", page.getCurrent() + 1);
		model.addAttribute("total", page.getPages());
		model.addAttribute("current", current);
		return "timu/tongji";
	}
	
	
	
	@PostMapping("/delete")
	@ResponseBody
	public Response deleteTimu(@RequestParam("id") Integer id,
			HttpSession session) {
		// User loginUser=(User) session.getAttribute("user") ;
		boolean i = timuService.removeById(id);
		if (i) {
			return Response.SUCCESS();
		}
		return Response.DEFEAT();
	}

	@GetMapping("/add")
	public String toInsertPerson() {
		return "timu/timu_add";
	}

	@PostMapping("/post")
	public String insert(Timu item, HttpSession session
	/* ,@RequestParam("file") MultipartFile uploadFile */
	) {
		if (session.getAttribute("user") != null) {
			User user = (User) session.getAttribute("user");
		}
		String dir = uploadFileLocation;
		/*
		 * try { if (StringUtils.hasLength(uploadFile.getOriginalFilename())) {
		 * String uuid = UUID.randomUUID().toString(); String suffix =
		 * uploadFile
		 * .getOriginalFilename().substring(uploadFile.getOriginalFilename
		 * ().lastIndexOf(".")); File file = new File(dir); if (!file.exists())
		 * { file.mkdir(); } // String
		 * saveFileName=uploadFile.getOriginalFilename(); String
		 * saveFileName=uuid + suffix; String savePath = dir+ "/" +
		 * saveFileName; uploadFile.transferTo(new File(savePath)); //
		 * item.setPhoto("/uploadFiles/"+saveFileName);
		 * resourceHandler=resourceHandler.replace("/**", "");
		 * item.setPhoto(resourceHandler+"/"+saveFileName);
		 * 
		 * 
		 * } } catch (IllegalStateException e) { e.printStackTrace(); } catch
		 * (IOException e) { e.printStackTrace(); }
		 */
		// item.setCreateTime(new Date());
		boolean b = timuService.save(item);
		return "redirect:/timu";
	}

	@GetMapping("/update")
	public String toUpdate(@RequestParam("id") Integer id, Model model) {
		Timu item = timuService.getById(id);
		model.addAttribute("timu", item);
		return "timu/timu_edit";
	}

	@PostMapping("/put")
	public String updatePerson(Timu item, HttpSession session) {
		// User loginUser=(User) session.getAttribute("user") ;

		timuService.updateById(item);
		return "redirect:/timu";
	}

	@GetMapping("/detail")
	public String toDetail(@RequestParam("id") Integer id, Model model) {
		Timu item = timuService.getById(id);
		model.addAttribute("item", item);
		return "timu/timu_detail";
	}

	/**
	 * json格式返回
	 * 
	 * @param id
	 * @return
	 */
	@PostMapping("/ajaxUpdate")
	@ResponseBody
	public Response ajaxUpdate(Timu item) {
		boolean i = timuService.updateById(item);
		if (i) {
			return Response.SUCCESS();
		}
		return Response.DEFEAT();
	}

	@PostMapping("/ajaxSave")
	@ResponseBody
	public Response ajaxSave(Timu item) {
		boolean i = timuService.save(item);
		if (i) {
			return Response.SUCCESS();
		}
		return Response.DEFEAT();
	}

	// 表单形式提交 链接参数形式提交
	@RequestMapping({ "/ajaxSelect" })
	public Response ajaxSelect(
			@RequestParam(value = "page", defaultValue = "1") Integer current,
			@RequestParam(value = "name", defaultValue = "") String name,
			@RequestParam(value = "keyword", defaultValue = "") String keyword,
			Model model) {
		Map<String, Object> searchMap = new HashMap<String, Object>();

		QueryWrapper<Timu> queryWrap = new QueryWrapper<Timu>();
		if (!"**null**".equals(name) && !"".equals(name)) {
			searchMap.put("name", name);
			queryWrap.like("name", name);
		}
		searchMap.put("name", name);
		if (!"**null**".equals(keyword) && !"".equals(keyword)) {

			/*
			 * queryWrap.and(wrapper -> wrapper.like("name", keyword)
			 * .or().like("name", keyword) );
			 */
		}
		searchMap.put("keyword", keyword);

		// queryWrap.orderByDesc("create_time");

		Map<String, Object> map = new HashMap<>();

		Page<Timu> page = new Page<Timu>(current, 10);
		page = timuService.page(page, queryWrap);

		map.put("searchMap", searchMap);

		map.put("list", page.getRecords());
		map.put("pre", page.getCurrent() - 1);
		map.put("next", page.getCurrent() + 1);
		map.put("total", page.getPages());
		map.put("current", current);

		return Response.SUCCESS(map);

	}

	// 以post JSON 格式请求数据
	@PostMapping({ "/ajaxJsonSelect" })
	@ResponseBody
	public Response ajaxPostBodySelect(@RequestBody Timu timu) {

		QueryWrapper<Timu> queryWrap = new QueryWrapper<Timu>();

		if (timu.getKeyword() != null) {
			queryWrap.and(wrapper -> wrapper.like("content", timu.getKeyword())
					.or().like("content", timu.getKeyword()));
		}

		// queryWrap.orderByDesc("create_time");

		Map<String, Object> map = new HashMap<>();

		Page<Timu> page = new Page<Timu>(timu.getCurrentPage(), 10);
		page = timuService.page(page, queryWrap);

		map.put("list", page.getRecords());
		map.put("pre", page.getCurrent() - 1);
		map.put("next", page.getCurrent() + 1);
		map.put("total", page.getPages());
		map.put("current", timu.getCurrentPage());

		return Response.SUCCESS(map);

	}

	@PostMapping("/upload")
    public @ResponseBody String upload( MultipartFile file,String fileDesc ,HttpServletRequest request){
        if(!file.isEmpty()){
            String uploadPath = uploadFileLocation;
            // 如果目录不存在则创建
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }
            String OriginalFilename = file.getOriginalFilename();//获取原文件名
            String suffixName = OriginalFilename.substring(OriginalFilename.lastIndexOf("."));//获取文件后缀名
            //重新随机生成名字
            String filename = UUID.randomUUID().toString() +suffixName;
            File localFile = new File(uploadPath+"\\"+filename);
            try {
                file.transferTo(localFile); //把上传的文件保存至本地
                /**
                 * 这里应该把filename保存到数据库,供前端访问时使用
                 */
//                Uploadfile upfile=new Uploadfile();
//                QueryWrapper<Bsinfo> queryWrapper=new QueryWrapper<>();
//                if (request.getSession().getAttribute("user") != null) {
//        			User user = (User) request.getSession().getAttribute("user");
//        			upfile.setStudentId(user.getId());
//                }
                ImportExcelUtil util=new ImportExcelUtil();
                InputStream in=new FileInputStream(localFile);
                try {
                	List<List<Object>>  excellist=util.getBankListByExcel(in, OriginalFilename);
                	System.out.println(excellist);
                	//入库开始
                	int lineCount=0;
                	for(List<Object> li :excellist ){
                		lineCount++;
                		if(lineCount==1){
                			continue;
                		}
                		try {
							String subject=null;
						    String cha=null;
						    String chb=null;
						    String chc=null;
						    String chd=null;
                			
						    subject=(String)li.get(0);
						    cha=(String)li.get(1);
						    chb=(String)li.get(2);
						    chc=(String)li.get(3);
						    chd=(String)li.get(4);
						  
						    Timu timu=new Timu();
						    timu.setSubject(subject);
						    timu.setCha(cha);
						    timu.setChb(chb);
						    timu.setChc(chc);
						    timu.setChd(chd);
						    timuMapper.insert(timu);
						    
							
						} catch (Exception e) {
							
//							log.error("第"+lineCount+"行导入失败");
//							log.error(e.getMessage());
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                		
                	    
                		
                			
                			
                		
                		
                	}
                	//入库结束
                	
                	
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                in.close();
                
                
                return OriginalFilename+"文件上传成功   <a href='/timu'>返回跳转</a>";//上传成功，返回保存的文件地址
            }catch (IOException e){
                e.printStackTrace();
                System.out.println("上传失败");
                return "";
            }
        }else{
            System.out.println("文件为空");
            return "文件为空,上传失败   <a href='/timu/'>返回跳转</a>";
        }
    }
}
