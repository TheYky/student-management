package demo.entity;

/**import com.iot.common.annotation.Excel;*/
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.TableId;

import java.io.Serializable;

import lombok.Data;
/**
 * 【请填写功能名称】对象 timu
 * 
 * @author admin
 * @date 2023-06-25
 */
@Data
public class Timu /*extends BaseEntity*/
{
    private static final long serialVersionUID = 1L;
//@TableId(value = "id", type = IdType.AUTO)
@TableField(exist=false)
private String keyword;

@TableField(exist=false)
private int currentPage;

@TableField(exist=false)
private int ch1Count;

@TableField(exist=false)
private int ch2Count;

@TableField(exist=false)
private int ch3Count;

@TableField(exist=false)
private int ch4Count;

@TableField(exist=false)
private String ch1Percent;

@TableField(exist=false)
private String ch2Percent;
@TableField(exist=false)
private String ch3Percent;
@TableField(exist=false)
private String ch4Percent;





    /** $column.columnComment */

    /**@Excel(name = "${comment}", readConverterExp = "$column.readConverterExp()")*/
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;




    /** 题目 */

    /**@Excel(name = "${comment}", readConverterExp = "题目")*/
    private String subject;




    /** 选项A */

    /**@Excel(name = "${comment}", readConverterExp = "选项A")*/
    private String cha;




    /** 选项B */

    /**@Excel(name = "${comment}", readConverterExp = "选项B")*/
    private String chb;




    /** 选项C */

    /**@Excel(name = "${comment}", readConverterExp = "选项C")*/
    private String chc;




    /** 选项D */

    /**@Excel(name = "${comment}", readConverterExp = "选项D")*/
    private String chd;




    /** 答案 */

    /**@Excel(name = "${comment}", readConverterExp = "答案")*/
    private String answer;




    /** 类型 */

    /**@Excel(name = "${comment}", readConverterExp = "类型")*/
    private String type;




    /** 状态 */

    /**@Excel(name = "${comment}", readConverterExp = "状态")*/
    private String status;


    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setSubject(String subject) 
    {
        this.subject = subject;
    }

    public String getSubject() 
    {
        return subject;
    }
    public void setCha(String cha) 
    {
        this.cha = cha;
    }

    public String getCha() 
    {
        return cha;
    }
    public void setChb(String chb) 
    {
        this.chb = chb;
    }

    public String getChb() 
    {
        return chb;
    }
    public void setChc(String chc) 
    {
        this.chc = chc;
    }

    public String getChc() 
    {
        return chc;
    }
    public void setChd(String chd) 
    {
        this.chd = chd;
    }

    public String getChd() 
    {
        return chd;
    }
    public void setAnswer(String answer) 
    {
        this.answer = answer;
    }

    public String getAnswer() 
    {
        return answer;
    }
    public void setType(String type) 
    {
        this.type = type;
    }

    public String getType() 
    {
        return type;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

 /*   @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("subject", getSubject())
            .append("cha", getCha())
            .append("chb", getChb())
            .append("chc", getChc())
            .append("chd", getChd())
            .append("answer", getAnswer())
            .append("type", getType())
            .append("status", getStatus())
            .toString();
    }*/
    @Override
    public String toString() {
        return ""
            +"id :"+ getId()+";"
            +"subject :"+ getSubject()+";"
            +"cha :"+ getCha()+";"
            +"chb :"+ getChb()+";"
            +"chc :"+ getChc()+";"
            +"chd :"+ getChd()+";"
            +"answer :"+ getAnswer()+";"
            +"type :"+ getType()+";"
            +"status :"+ getStatus()+";"
            ;
    }
}
