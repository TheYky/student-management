package demo.entity;

/**import com.iot.common.annotation.Excel;*/
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;

import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonFormat;

import com.baomidou.mybatisplus.annotation.TableId;

import java.io.Serializable;
import lombok.Data;
/**
 * 【请填写功能名称】对象 answer_log
 * 
 * @author admin
 * @date 2023-06-25
 */
@Data
public class AnswerLog /*extends BaseEntity*/
{
    private static final long serialVersionUID = 1L;
//@TableId(value = "id", type = IdType.AUTO)
@TableField(exist=false)
private String keyword;

@TableField(exist=false)
private int currentPage;




    /** ID */

    /**@Excel(name = "${comment}", readConverterExp = "ID")*/
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;




    /** 问卷ID */

    /**@Excel(name = "${comment}", readConverterExp = "问卷ID")*/
    private Long wenjuanId;




    /** 答卷ID */

    /**@Excel(name = "${comment}", readConverterExp = "答卷ID")*/
    private Long answerId;




    /** 题目ID */

    /**@Excel(name = "${comment}", readConverterExp = "题目ID")*/
    private Long timuId;




    /** 答题人ID */

    /**@Excel(name = "${comment}", readConverterExp = "答题人ID")*/
    private Long answerUid;




    /** 选择项 */

    /**@Excel(name = "${comment}", readConverterExp = "选择项")*/
    private String timuChoice;




    /** 创建时间 */

    @JsonFormat(pattern = "yyyy-MM-dd")
    /*@Excel(name = "${comment}", width = 30, dateFormat = "yyyy-MM-dd")*/
    private Date createTime;


    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setWenjuanId(Long wenjuanId) 
    {
        this.wenjuanId = wenjuanId;
    }

    public Long getWenjuanId() 
    {
        return wenjuanId;
    }
    public void setAnswerId(Long answerId) 
    {
        this.answerId = answerId;
    }

    public Long getAnswerId() 
    {
        return answerId;
    }
    public void setTimuId(Long timuId) 
    {
        this.timuId = timuId;
    }

    public Long getTimuId() 
    {
        return timuId;
    }
    public void setAnswerUid(Long answerUid) 
    {
        this.answerUid = answerUid;
    }

    public Long getAnswerUid() 
    {
        return answerUid;
    }
    public void setTimuChoice(String timuChoice) 
    {
        this.timuChoice = timuChoice;
    }

    public String getTimuChoice() 
    {
        return timuChoice;
    }

 /*   @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("wenjuanId", getWenjuanId())
            .append("answerId", getAnswerId())
            .append("timuId", getTimuId())
            .append("answerUid", getAnswerUid())
            .append("timuChoice", getTimuChoice())
            .append("createTime", getCreateTime())
            .toString();
    }*/
    @Override
    public String toString() {
        return ""
            +"id :"+ getId()+";"
            +"wenjuanId :"+ getWenjuanId()+";"
            +"answerId :"+ getAnswerId()+";"
            +"timuId :"+ getTimuId()+";"
            +"answerUid :"+ getAnswerUid()+";"
            +"timuChoice :"+ getTimuChoice()+";"
            +"createTime :"+ getCreateTime()+";"
            ;
    }
}
