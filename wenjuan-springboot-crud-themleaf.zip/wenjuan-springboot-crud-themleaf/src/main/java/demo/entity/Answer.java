package demo.entity;

/**import com.iot.common.annotation.Excel;*/
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;

import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonFormat;

import com.baomidou.mybatisplus.annotation.TableId;

import java.io.Serializable;
import lombok.Data;
/**
 * 【请填写功能名称】对象 answer
 * 
 * @author admin
 * @date 2023-06-25
 */
@Data
public class Answer /*extends BaseEntity*/
{
    private static final long serialVersionUID = 1L;
//@TableId(value = "id", type = IdType.AUTO)
@TableField(exist=false)
private String keyword;

@TableField(exist=false)
private int currentPage;




    /** ID */

    /**@Excel(name = "${comment}", readConverterExp = "ID")*/
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;




    /** 问卷ID */

    /**@Excel(name = "${comment}", readConverterExp = "问卷ID")*/
    private Long wenjuanId;




    /** 答题人ID */

    /**@Excel(name = "${comment}", readConverterExp = "答题人ID")*/
    private Long answerUid;




    /** 创建时间 */

    @JsonFormat(pattern = "yyyy-MM-dd")
    /*@Excel(name = "${comment}", width = 30, dateFormat = "yyyy-MM-dd")*/
    private Date createTime;




    /** $column.columnComment */

    /**@Excel(name = "${comment}", readConverterExp = "$column.readConverterExp()")*/
    private Long answerCount;


    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setWenjuanId(Long wenjuanId) 
    {
        this.wenjuanId = wenjuanId;
    }

    public Long getWenjuanId() 
    {
        return wenjuanId;
    }
    public void setAnswerUid(Long answerUid) 
    {
        this.answerUid = answerUid;
    }

    public Long getAnswerUid() 
    {
        return answerUid;
    }
    public void setAnswerCount(Long answerCount) 
    {
        this.answerCount = answerCount;
    }

    public Long getAnswerCount() 
    {
        return answerCount;
    }

 /*   @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("wenjuanId", getWenjuanId())
            .append("answerUid", getAnswerUid())
            .append("createTime", getCreateTime())
            .append("answerCount", getAnswerCount())
            .toString();
    }*/
    @Override
    public String toString() {
        return ""
            +"id :"+ getId()+";"
            +"wenjuanId :"+ getWenjuanId()+";"
            +"answerUid :"+ getAnswerUid()+";"
            +"createTime :"+ getCreateTime()+";"
            +"answerCount :"+ getAnswerCount()+";"
            ;
    }
}
