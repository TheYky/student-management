package demo.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
/**import com.iot.common.annotation.Excel;*/
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.TableId;

import java.io.Serializable;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
/**
 * 【请填写功能名称】对象 wenjuan
 * 
 * @author admin
 * @date 2023-06-25
 */
@Data
public class Wenjuan /*extends BaseEntity*/
{
    private static final long serialVersionUID = 1L;
//@TableId(value = "id", type = IdType.AUTO)
@TableField(exist=false)
private String keyword;

@TableField(exist=false)
private int currentPage;


@TableField(exist=false)
private List<Long> timuList;


    /** ID */

    /**@Excel(name = "${comment}", readConverterExp = "ID")*/
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;


    private Integer countLimit;

    /** 项目名称 */

    /**@Excel(name = "${comment}", readConverterExp = "项目名称")*/
    private String projectName;




    /** 问卷类型 */

    /**@Excel(name = "${comment}", readConverterExp = "问卷类型")*/
    private String type;




    /** 问卷名称 */

    /**@Excel(name = "${comment}", readConverterExp = "问卷名称")*/
    private String wenjuanName;




    /** 备注 */

    /**@Excel(name = "${comment}", readConverterExp = "备注")*/
    private String remark;




    /** 创建时间 */

    @JsonFormat(pattern = "yyyy-MM-dd")
    /*@Excel(name = "${comment}", width = 30, dateFormat = "yyyy-MM-dd")*/
    private Date createTime;




    /** 题目ID列表 */

    /**@Excel(name = "${comment}", readConverterExp = "题目ID列表")*/
    private String timuIdlist;


   

    /** 开始时间 */

    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    /*@Excel(name = "${comment}", width = 30, dateFormat = "yyyy-MM-dd")*/
    private Date starttime;

    


    /** 结束时间 */

    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    /*@Excel(name = "${comment}", width = 30, dateFormat = "yyyy-MM-dd")*/
    private Date endtime;


    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setProjectName(String projectName) 
    {
        this.projectName = projectName;
    }

    public String getProjectName() 
    {
        return projectName;
    }
    public void setType(String type) 
    {
        this.type = type;
    }

    public String getType() 
    {
        return type;
    }
    public void setWenjuanName(String wenjuanName) 
    {
        this.wenjuanName = wenjuanName;
    }

    public String getWenjuanName() 
    {
        return wenjuanName;
    }
    public void setTimuIdlist(String timuIdlist) 
    {
        this.timuIdlist = timuIdlist;
    }

    public String getTimuIdlist() 
    {
        return timuIdlist;
    }
    public void setStarttime(Date starttime) 
    {
        this.starttime = starttime;
    }

    public Date getStarttime() 
    {
        return starttime;
    }
    public void setEndtime(Date endtime) 
    {
        this.endtime = endtime;
    }

    public Date getEndtime() 
    {
        return endtime;
    }

 /*   @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("projectName", getProjectName())
            .append("type", getType())
            .append("wenjuanName", getWenjuanName())
            .append("remark", getRemark())
            .append("createTime", getCreateTime())
            .append("timuIdlist", getTimuIdlist())
            .append("starttime", getStarttime())
            .append("endtime", getEndtime())
            .toString();
    }*/
    @Override
    public String toString() {
        return ""
            +"id :"+ getId()+";"
            +"projectName :"+ getProjectName()+";"
            +"type :"+ getType()+";"
            +"wenjuanName :"+ getWenjuanName()+";"
            +"remark :"+ getRemark()+";"
            +"createTime :"+ getCreateTime()+";"
            +"timuIdlist :"+ getTimuIdlist()+";"
            +"starttime :"+ getStarttime()+";"
            +"endtime :"+ getEndtime()+";"
            ;
    }
}
