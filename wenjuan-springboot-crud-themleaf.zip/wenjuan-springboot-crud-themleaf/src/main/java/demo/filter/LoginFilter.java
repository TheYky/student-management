package demo.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import demo.entity.User;

//@Component
//@WebFilter(filterName = "loginFilter", urlPatterns = "/*" , initParams = {
//        @WebInitParam(name = "URL", value = "http://localhost:8080")})
//public class LoginFilter implements Filter {
//
//	//不用过滤的访问链接
//	String[] notFilterUrls={"/login","/visitor","/user/login","/register","/user/register","/bootstrap-dist","/assets"  };
//	//不再重定向的url  
//	String[] homeRedictUrl={"/","/index"};
//	
//	
//	    @Override
//	    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
//	        HttpServletRequest request = (HttpServletRequest) servletRequest;
//	        HttpServletResponse response = (HttpServletResponse) servletResponse;
//	        boolean notFilter=false;
//	       
//	        for(String url:notFilterUrls){
//	        	 if(request.getRequestURI().startsWith(url)){
//	 	        	notFilter=true;
//	 	        }
//	        }
//	        
//	        if(notFilter){
//	        	 filterChain.doFilter(servletRequest, servletResponse);
//	        	 return;
//	        }
//	        
//	        
//	        String username="";
//	        User user;
//	        System.out.println("loginFilter,"+request.getRequestURI());
//	        if(request.getSession().getAttribute("user")!=null){
//	        	user=(User)request.getSession().getAttribute("user")  ;
//	        }else{
//	        	//首页访问url 重定向url不再进行重定向     
//	        	for(String url:homeRedictUrl){
//		        	 if(request.getRequestURI().equals(url)){
//		        		 filterChain.doFilter(servletRequest, servletResponse);
//		        		 return ;
//		 	        }
//		        }
//	        	response.sendRedirect("/login");
//	        	return ;
//	        }
//	        
//	       /* if("".equals( username)){
//	        	response.sendRedirect("/login");
//	        }*/
//	        
//	        //执行
//	        filterChain.doFilter(servletRequest, servletResponse);
//	    }
//	
//	
//	
//
//}
