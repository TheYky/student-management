package demo.config;

import demo.entity.User;

public class Constants {
	
	
	
	
	

}
