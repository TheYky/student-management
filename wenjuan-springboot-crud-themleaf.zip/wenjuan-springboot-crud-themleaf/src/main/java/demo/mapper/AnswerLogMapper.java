package demo.mapper;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import demo.entity.AnswerLog;
import com.baomidou.mybatisplus.core.metadata.IPage;

/**
 * 【请填写功能名称】Mapper接口
 * 
 * @author admin
 * @date 2023-06-25
 */
public interface AnswerLogMapper extends BaseMapper<AnswerLog>
{

      //接收的对象中若比查询到的字段少  则可以使用exsit=false
     IPage<AnswerLog> getMysqlByPage(IPage<AnswerLog> page ,@Param("queryStr") String queryStr);


     //分页查询样例2    参数通过map.变量名使用   结果通过map接收
     IPage<Map<String,Object>> getMysqlByPageMap(IPage<AnswerLog> page ,@Param("map") Map<String,Object> map);
     
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    public AnswerLog selectAnswerLogById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param answerLog 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<AnswerLog> selectAnswerLogList(AnswerLog answerLog);

    /**
     * 新增【请填写功能名称】
     * 
     * @param answerLog 【请填写功能名称】
     * @return 结果
     */
    public int insertAnswerLog(AnswerLog answerLog);

    /**
     * 修改【请填写功能名称】
     * 
     * @param answerLog 【请填写功能名称】
     * @return 结果
     */
    public int updateAnswerLog(AnswerLog answerLog);

    /**
     * 删除【请填写功能名称】
     * 
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteAnswerLogById(Long id);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteAnswerLogByIds(String[] ids);
}
