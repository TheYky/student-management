package demo.utils;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class Response {
    private Integer code;
    private Map<String, Object> tags=new HashMap<String, Object>();

    
    
    public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public Map<String, Object> getTags() {
		return tags;
	}

	public void setTags(Map<String, Object> tags) {
		this.tags = tags;
	}

	public static Response SUCCESS() {
        Response response = new Response();
        response.setCode(1);
        return response;
    }
	
	public static Response SUCCESS(Map<String,Object> map) {
        Response response = new Response();
        response.setCode(1);
        response.setTags(map);
        return response;
    }
	
	
	
	public static Response Fail() {
        Response response = new Response();
        response.setCode(99);
        return response;
    }
	
	public static Response Fail(Map<String,Object> map) {
        Response response = new Response();
        response.setCode(99);
        response.setTags(map);
        return response;
    }
	
	

    public static Response DEFEAT() {
        Response response = new Response();
        response.setCode(-1);
        return response;
    }

   
    
    
}
