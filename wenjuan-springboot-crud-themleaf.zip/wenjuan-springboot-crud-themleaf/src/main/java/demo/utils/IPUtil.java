package demo.utils;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class IPUtil {
    /**
     * 获取本地电脑ip地址
     * @return
     */
    public static String getLocalIpAddress(){
        InetAddress ip;      //用于获取IP(因为是静态的所以不需要使用new来实例化
        String IP = null;    //用于返回IP
        try {
            ip = Inet4Address.getLocalHost();    //获取IP
            IP = ip.getHostAddress();        	//以字符串形式存储IP
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return IP;
    }

    public static void main(String[] args) {
        System.out.println(getLocalIpAddress());
    }
}
