package demo.service;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import demo.entity.User;

public interface UserService {
    User login(User user);

    int register(User user);
    
    List<User> listAll();

	int updateUser(User user);

	User getUserById(Integer id);

	int addNewUser(User user);

	int removeUserById(Integer id);

	IPage<User> getUserByPage(Page<User> page, Map<String, Object> map);
}
