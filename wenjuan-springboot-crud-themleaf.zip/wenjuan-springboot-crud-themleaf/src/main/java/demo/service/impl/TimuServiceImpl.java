package demo.service.impl;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import demo.mapper.TimuMapper;
import demo.entity.Timu;
import demo.service.TimuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
/*import com.iot.common.core.text.Convert;*/

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author admin
 * @date 2023-06-25
 */
@Service
public class TimuServiceImpl extends ServiceImpl<TimuMapper, Timu>  implements TimuService 
{
    @Autowired
    private TimuMapper timuMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    @Override
    public Timu selectTimuById(Long id)
    {
        return timuMapper.selectTimuById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param timu 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<Timu> selectTimuList(Timu timu)
    {
        return timuMapper.selectTimuList(timu);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param timu 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertTimu(Timu timu)
    {
        return timuMapper.insertTimu(timu);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param timu 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateTimu(Timu timu)
    {
        return timuMapper.updateTimu(timu);
    }

    /**
     * 删除【请填写功能名称】对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteTimuByIds(String ids)
    {
        return timuMapper.deleteTimuByIds(ids.split(";"));
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    @Override
    public int deleteTimuById(Long id)
    {
        return timuMapper.deleteTimuById(id);
    }
}
