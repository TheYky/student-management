package demo.service.impl;

import java.util.Date;
import java.util.List;
//import com.iot.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import demo.mapper.AnswerMapper;
import demo.entity.Answer;
import demo.service.AnswerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
/*import com.iot.common.core.text.Convert;*/

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author admin
 * @date 2023-06-25
 */
@Service
public class AnswerServiceImpl extends ServiceImpl<AnswerMapper, Answer>  implements AnswerService 
{
    @Autowired
    private AnswerMapper answerMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    @Override
    public Answer selectAnswerById(Long id)
    {
        return answerMapper.selectAnswerById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param answer 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<Answer> selectAnswerList(Answer answer)
    {
        return answerMapper.selectAnswerList(answer);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param answer 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertAnswer(Answer answer)
    {
        answer.setCreateTime(new Date());
        return answerMapper.insertAnswer(answer);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param answer 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateAnswer(Answer answer)
    {
        return answerMapper.updateAnswer(answer);
    }

    /**
     * 删除【请填写功能名称】对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAnswerByIds(String ids)
    {
        return answerMapper.deleteAnswerByIds(ids.split(";"));
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    @Override
    public int deleteAnswerById(Long id)
    {
        return answerMapper.deleteAnswerById(id);
    }
}
