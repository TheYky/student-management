package demo.service.impl;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import demo.entity.User;
import demo.mapper.UserMapper;
import demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper mapper;

    @Override
    public User login(User user) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("username", user.getUsername());
        wrapper.eq("password", user.getPassword());
        wrapper.eq("type", user.getType());
        User login = mapper.selectOne(wrapper);
        return login;
    }

    @Override
    public int register(User user) {
        int result = mapper.insert(user);
        return result;
    }

	@Override
	public List<User> listAll() {
		List<User> list=mapper.selectList(null);
		
		return list;
	}

	@Override
	public int updateUser(User user) {
		return   mapper.updateById(user);
	}

	@Override
	public User getUserById(Integer id) {
		return mapper.selectById(id);
	}

	@Override
	public int addNewUser(User user) {
		return mapper.insert(user);
	}

	@Override
	public int removeUserById(Integer id) {
		return mapper.deleteById(id);
	}

	@Override
	public IPage<User> getUserByPage(Page<User> page, Map<String, Object> map) {
		QueryWrapper<User> queryWrapper=new QueryWrapper<User>();
    	if(map.get("username")!=null){
    	queryWrapper.eq("username",map.get("username"));
    	}
        return mapper.selectPage(page, queryWrapper);
	}
}
