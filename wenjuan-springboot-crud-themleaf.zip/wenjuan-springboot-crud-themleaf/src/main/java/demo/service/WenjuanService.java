package demo.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import demo.entity.Wenjuan;

/**
 * 【请填写功能名称】Service接口
 * 
 * @author admin
 * @date 2023-06-25
 */
public interface WenjuanService  extends IService<Wenjuan>
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    public Wenjuan selectWenjuanById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param wenjuan 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<Wenjuan> selectWenjuanList(Wenjuan wenjuan);

    /**
     * 新增【请填写功能名称】
     * 
     * @param wenjuan 【请填写功能名称】
     * @return 结果
     */
    public int insertWenjuan(Wenjuan wenjuan);

    /**
     * 修改【请填写功能名称】
     * 
     * @param wenjuan 【请填写功能名称】
     * @return 结果
     */
    public int updateWenjuan(Wenjuan wenjuan);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteWenjuanByIds(String ids);

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteWenjuanById(Long id);
}
