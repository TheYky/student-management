package demo.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import demo.entity.AnswerLog;

/**
 * 【请填写功能名称】Service接口
 * 
 * @author admin
 * @date 2023-06-25
 */
public interface AnswerLogService  extends IService<AnswerLog>
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    public AnswerLog selectAnswerLogById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param answerLog 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<AnswerLog> selectAnswerLogList(AnswerLog answerLog);

    /**
     * 新增【请填写功能名称】
     * 
     * @param answerLog 【请填写功能名称】
     * @return 结果
     */
    public int insertAnswerLog(AnswerLog answerLog);

    /**
     * 修改【请填写功能名称】
     * 
     * @param answerLog 【请填写功能名称】
     * @return 结果
     */
    public int updateAnswerLog(AnswerLog answerLog);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteAnswerLogByIds(String ids);

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteAnswerLogById(Long id);
}
